﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO;


namespace GroupProject
{
    public partial class Form1 : Form
    {
        // Create a DataTable to store materials
        private DataTable materialsTable;

        public Form1()
        {
            InitializeComponent();

            // Initialize the DataTable
            InitializeMaterialsTable();
        }

        private void InitializeMaterialsTable()
        {
            materialsTable = new DataTable();

            // Add columns to the DataTable
            materialsTable.Columns.Add("Description", typeof(string));
            materialsTable.Columns.Add("Quantity", typeof(int));
            materialsTable.Columns.Add("Cost", typeof(decimal));

            // Set the DataTable as the DataSource for the DataGridView
            dataGridView1.DataSource = materialsTable;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            // Get values from textboxes
            string description = textBox1.Text;
            int quantity = int.Parse(textBox2.Text);
            decimal cost = decimal.Parse(textBox3.Text);

            // Add a new row to the DataTable
            materialsTable.Rows.Add(description, quantity, cost);

            // Save to text file
            using (StreamWriter writer = new StreamWriter("materials.txt", true))
            {
                writer.WriteLine($"{description},{quantity},{cost}");
            }

            // Clear textboxes
            ClearTextBoxes();
        }


        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Clear textboxes
            ClearTextBoxes();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Calculate total cost for each material
            foreach (DataRow row in materialsTable.Rows)
            {
                int quantity = Convert.ToInt32(row["Quantity"]);
                decimal cost = Convert.ToDecimal(row["Cost"]);
                decimal totalCost = quantity * cost;

                // Add or update a column for total cost
                if (!materialsTable.Columns.Contains("TotalCost"))
                    materialsTable.Columns.Add("TotalCost", typeof(decimal));

                row["TotalCost"] = totalCost;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Delete selected row from the DataGridView
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                materialsTable.Rows.RemoveAt(selectedRow.Index);
            }
        }
    }
}